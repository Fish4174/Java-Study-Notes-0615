public class Student implements Comparable<Student>
{
    private String name;
    private String sex;
    private int age;
    public Student(){}
    public Student(String name, String sex, int age)
    {
        this.name = name;
        this.sex = sex;
        this.age = age;
    }
    public String getName()
    {
        return name;
    }
    public String getSex()
    {
        return sex;
    }
    public int getAge()
    {
        return age;
    }
    @Override
    public int compareTo(Student student)
    {
        if(this.age > student.age)
            return 1;
        else if(this.age < student.age)
            return -1;
        else
            return 0;
    }
}
import java.util.LinkedList;

public class Monkey
{
    public static void main(String[] args)
    {
        var monkeyList = new LinkedList<Integer>();
        for(int i = 1; i <= 100; i ++)
            monkeyList.add(i);
        int count = 0;//报数器
        int index = 0;//当前猴子在链表中的索引
        while(monkeyList.size() > 1)
        {
            count ++;//报数
            if(count == 3)
            {
                monkeyList.remove(index);
                count = 0;//报数器清零
            }
            else
                index ++;
            if(index == monkeyList.size())//表走完了，回到表头
                index = 0;
        }
        System.out.println("大王是" + monkeyList.get(0));
    }
}

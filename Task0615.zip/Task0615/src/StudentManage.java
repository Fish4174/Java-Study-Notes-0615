import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class StudentManage
{
    public static void main(String[] args)
    {
        var stuList = new ArrayList<Student>();
        stuList.add(new Student("Tina", "男", 21));
        stuList.add(new Student("Fish", "男", 20));
        stuList.add(new Student("Tear", "女", 19));
        Collections.sort(stuList);
        //迭代器
        Iterator<Student> iterator = stuList.iterator();
        while(iterator.hasNext())
        {
            //迭代器中存在下一个元素
            //取出下一个元素（学生）
            Student student = iterator.next();
            System.out.println("学生姓名：" + student.getName() + "，性别：" + student.getSex() + "，年龄：" + student.getAge());
        }
    }
}